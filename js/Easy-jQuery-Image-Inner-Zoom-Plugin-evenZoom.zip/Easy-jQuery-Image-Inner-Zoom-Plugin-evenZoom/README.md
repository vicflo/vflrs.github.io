# evenZoom
jQuery image zoom plugin by even.lv web studio.
evenZoom is a jQuery plugin, that adds zoom functionality to images

Please visit our website: http://even.lv.

## Live demo and documentation
http://www.even.lv/files/creative/evenZoom/demo
